LISTBOX_MIMETYPE = "application/x-item"

# <20
OP_NODE_INPUT = 1
OP_NODE_OUTPUT = 2
OP_NODE_Value = 3

# >=20
OP_NODE_Conv1d = 20
OP_NODE_Conv2d = 21
OP_NODE_Conv3d = 22
OP_NODE_ConvTranspose1d = 23
OP_NODE_ConvTranspose2d = 24
OP_NODE_ConvTranspose3d = 25
OP_NODE_MaxPool1d = 26
OP_NODE_MaxPool2d = 27
OP_NODE_MaxPool3d = 28
OP_NODE_AvgPool1d = 29
OP_NODE_AvgPool2d = 30
OP_NODE_AvgPool3d = 31
OP_NODE_AdaptiveMaxPool1d = 32
OP_NODE_AdaptiveMaxPool2d = 33
OP_NODE_AdaptiveMaxPool3d = 34
OP_NODE_AdaptiveAvgPool1d = 35
OP_NODE_AdaptiveAvgPool2d = 36
OP_NODE_AdaptiveAvgPool3d = 37
OP_NODE_RELU = 38
OP_NODE_GELU = 39
OP_NODE_Softmax = 40
OP_NODE_Sigmoid = 41
OP_NODE_BatchNorm1d = 42
OP_NODE_BatchNorm2d = 43
OP_NODE_BatchNorm3d = 44
OP_NODE_LayerNorm = 45
OP_NODE_Linear = 46
OP_NODE_Dropout = 47
OP_NODE_Dropout1d = 48
OP_NODE_Dropout2d = 49
OP_NODE_Dropout3d = 50
OP_NODE_Flatten = 51
OP_NODE_Unflatten = 52
OP_NODE_Custom = 53

# >=500
OP_NODE_ADD = 500
OP_NODE_SUB = 501
OP_NODE_MUL = 502
OP_NODE_DIV = 503
OP_NODE_SUM = 504
OP_NODE_Matmul = 505
OP_NODE_Reshape = 506
OP_NODE_Rearrange = 507
OP_NODE_Reduce = 508
OP_NODE_Repeat = 509
OP_NODE_Stack0 = 510
OP_NODE_Stack1 = 511
OP_NODE_Cat0 = 512
OP_NODE_Cat1 = 513

CALC_NODES = {
}


class ConfException(Exception): pass


class InvalidNodeRegistration(ConfException): pass


class OpCodeNotRegistered(ConfException): pass


def register_node_now(op_code, class_reference):
    if op_code in CALC_NODES:
        raise InvalidNodeRegistration("Duplicate node registration of '%s'. There is already %s" % (
            op_code, CALC_NODES[op_code]
        ))
    CALC_NODES[op_code] = class_reference


def register_node(op_code):
    def decorator(original_class):
        register_node_now(op_code, original_class)
        return original_class

    return decorator


def get_class_from_opcode(op_code):
    if op_code not in CALC_NODES: raise OpCodeNotRegistered("OpCode '%d' is not registered" % op_code)
    return CALC_NODES[op_code]


# import all nodes and register them
import input, output, operations
