from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QTextEdit

from calc_conf import (register_node, OP_NODE_Dropout1d,
                                                   OP_NODE_Dropout2d, OP_NODE_Dropout3d,
                                                   OP_NODE_Conv3d, OP_NODE_ADD,
                                                   OP_NODE_SUB, OP_NODE_MUL,
                                                   OP_NODE_DIV, OP_NODE_BatchNorm2d,
                                                   OP_NODE_Conv2d, OP_NODE_Flatten,
                                                   OP_NODE_Linear, OP_NODE_MaxPool1d,
                                                   OP_NODE_MaxPool2d, OP_NODE_MaxPool3d,
                                                   OP_NODE_RELU, OP_NODE_Dropout,
                                                   OP_NODE_AvgPool1d, OP_NODE_AvgPool2d, OP_NODE_AvgPool3d,
                                                   OP_NODE_AdaptiveAvgPool1d, OP_NODE_AdaptiveAvgPool2d,
                                                   OP_NODE_AdaptiveAvgPool3d, OP_NODE_Softmax,
                                                   OP_NODE_SUM, OP_NODE_Rearrange,
                                                   OP_NODE_Reduce, OP_NODE_Matmul,
                                                   OP_NODE_Sigmoid, OP_NODE_Stack0,
                                                   OP_NODE_Cat0, OP_NODE_AdaptiveMaxPool1d,
                                                   OP_NODE_AdaptiveMaxPool2d, OP_NODE_AdaptiveMaxPool3d,
                                                   OP_NODE_Cat1, OP_NODE_BatchNorm1d, OP_NODE_BatchNorm3d,
                                                   OP_NODE_Conv1d, OP_NODE_LayerNorm,
                                                   OP_NODE_GELU, OP_NODE_Repeat,
                                                   OP_NODE_ConvTranspose1d, OP_NODE_ConvTranspose2d,
                                                   OP_NODE_ConvTranspose3d, OP_NODE_Unflatten,
                                                   OP_NODE_Stack1, OP_NODE_Reshape,
                                                   OP_NODE_Custom)
from calc_node_base import CalcNode, CalcNode2, CalcGraphicsNode
import torch
from einops.layers.torch import Rearrange, Reduce
from einops import repeat
from calc_node_params_base import CalcGraphicsNode
from node_content_widget import QDMNodeContentWidget
from utils_no_qt import dumpException


def convert_string_to_dict(input_string):
    data = input_string.split(' ')
    result_dict = {}
    try:
        for item in data:
            if '=' in item:  # Check if line contains '='
                key, value = item.split('=')
                result_dict[key.strip()] = eval(value.strip())
    except Exception as e:
        print('An  exception  occurred:', e)
    return result_dict


pas = str({'in_channels': 3,
           'out_channels': 16,
           'kernel_size': 3})


class CalcInputContent(QDMNodeContentWidget):
    def initUI(self):
        self.edit = QTextEdit(pas, self)
        # self.edit.setAlignment(Qt.AlignRight)
        self.edit.setFixedSize(155, 105)
        font = QFont()
        font.setPointSize(12)
        self.edit.setFont(font)
        # 设置多行文本框的背景颜色为黑色
        self.edit.setStyleSheet('background-color:#292929;margin-left:6')
        # self.edit.setPlaceholderText("Enter text here")
        # self.edit.setObjectName(self.node.content_label_objname)
        # self.height = 120

    def serialize(self):
        res = super().serialize()
        res['value'] = self.edit.toPlainText()
        return res

    def deserialize(self, data, hashmap={}):
        res = super().deserialize(data, hashmap)
        try:
            value = data['value']
            self.edit.setText(value)
            return True & res
        except Exception as e:
            dumpException(e)
        return res


@register_node(OP_NODE_ADD)
class CalcNode_Add(CalcNode2):
    # icon = "icons/add.png"
    op_code = OP_NODE_ADD
    op_title = "Add"
    content_label = "+"
    content_label_objname = "calc_node_bg"

    def evalOperation(self, input1, input2):
        return input1 + input2


@register_node(OP_NODE_SUB)
class CalcNode_Sub(CalcNode2):
    # icon = "icons/sub.png"
    op_code = OP_NODE_SUB
    op_title = "Substract"
    content_label = "-"
    content_label_objname = "calc_node_bg"

    def evalOperation(self, input1, input2):
        return input1 - input2


@register_node(OP_NODE_MUL)
class CalcNode_Mul(CalcNode2):
    # icon = "icons/mul.png"
    op_code = OP_NODE_MUL
    op_title = "Multiply"
    content_label = "*"
    content_label_objname = "calc_node_mul"

    def evalOperation(self, input1, input2):
        # print('foo')
        return input1 * input2


@register_node(OP_NODE_DIV)
class CalcNode_Div(CalcNode2):
    # icon = "icons/divide.png"
    op_code = OP_NODE_DIV
    op_title = "Divide"
    content_label = "/"
    content_label_objname = "calc_node_div"

    def evalOperation(self, input1, input2):
        return input1 / input2


# way how to register by function call
# register_node_now(OP_NODE_ADD, CalcNode_Add)

@register_node(OP_NODE_BatchNorm2d)
class CalcNode_BatchNorm2d(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_BatchNorm2d
    op_title = "BatchNorm2d"
    # content_label = "log"
    content_label_objname = "calc_node_BatchNorm2d"

    def initInnerClasses(self):
        global pas
        pas = """
num_features=10
eps=1e-05
momentum=0.1
affine=True
track_running_stats=True
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.BatchNorm2d' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.BatchNorm2d(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


# torch.nn.BatchNorm2d(num_features=)
@register_node(OP_NODE_BatchNorm1d)
class CalcNode_BatchNorm1d(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_BatchNorm1d
    op_title = "BatchNorm1d"
    # content_label = "log"
    content_label_objname = "calc_node_BatchNorm1d"

    def initInnerClasses(self):
        global pas
        pas = """
num_features=10
eps=1e-05
momentum=0.1
affine=True
track_running_stats=True
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.BatchNorm1d' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.BatchNorm1d(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_BatchNorm3d)
class CalcNode_BatchNorm3d(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_BatchNorm3d
    op_title = "BatchNorm3d"
    # content_label = "log"
    content_label_objname = "calc_node_BatchNorm3d"

    def initInnerClasses(self):
        global pas
        pas = """
num_features=10
eps=1e-05
momentum=0.1
affine=True
track_running_stats=True
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.BatchNorm3d' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.BatchNorm3d(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_ConvTranspose1d)
class CalcNode_ConvTranspose1d(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_ConvTranspose1d
    op_title = "ConvTranspose1d"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_ConvTranspose1d"

    def initInnerClasses(self):
        global pas
        pas = """
in_channels=3
out_channels=16
kernel_size=3
stride=1
padding=0
output_padding=0
groups=1
bias=True
dilation=1
padding_mode='zeros'
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        if input1 is None:
            self.markInvalid()
            return
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.ConvTranspose1d' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.ConvTranspose1d(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_ConvTranspose2d)
class CalcNode_ConvTranspose2d(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_ConvTranspose2d
    op_title = "ConvTranspose2d"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_ConvTranspose2d"

    def initInnerClasses(self):
        global pas
        pas = """
in_channels=3
out_channels=16
kernel_size=3
stride=1
padding=0
output_padding=0
groups=1
bias=True
dilation=1
padding_mode='zeros'
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        if input1 is None:
            self.markInvalid()
            return
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.ConvTranspose2d' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.ConvTranspose2d(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_ConvTranspose3d)
class CalcNode_ConvTranspose3d(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_ConvTranspose3d
    op_title = "ConvTranspose3d"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_ConvTranspose3d"

    def initInnerClasses(self):
        global pas
        pas = """
in_channels=3
out_channels=16
kernel_size=3
stride=1
padding=0
output_padding=0
groups=1
bias=True
dilation=1
padding_mode='zeros'
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        if input1 is None:
            self.markInvalid()
            return
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.ConvTranspose3d' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.ConvTranspose3d(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_Conv3d)
class CalcNode_CONV3D(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_Conv3d
    op_title = "Conv3d"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_conv3d"

    def initInnerClasses(self):
        global pas
        pas = """
in_channels=3
out_channels=16
kernel_size=3
stride=1
padding=0
dilation=1
groups=1
bias=True
padding_mode='zeros'
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        if input1 is None:
            self.markInvalid()
            return
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.Conv3d' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.Conv3d(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_Conv2d)
class CalcNode_CONV2D(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_Conv2d
    op_title = "Conv2d"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_conv2d"

    def initInnerClasses(self):
        global pas
        pas = """
in_channels=3
out_channels=16
kernel_size=3
stride=1
padding=0
dilation=1
groups=1
bias=True
padding_mode='zeros'
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        if input1 is None:
            self.markInvalid()
            return
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.Conv2d' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.Conv2d(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_Conv1d)
class CalcNode_CONV1D(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_Conv1d
    op_title = "Conv1d"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_conv1d"

    def initInnerClasses(self):
        global pas
        pas = """
in_channels=3
out_channels=16
kernel_size=3
stride=1
padding=0
dilation=1
groups=1
bias=True
padding_mode='zeros'
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.Conv1d' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.Conv1d(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_Flatten)
class CalcNode_FLATTEN(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_Flatten
    op_title = "Flatten"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_flatten"

    def initInnerClasses(self):
        global pas
        pas = """
start_dim=1
end_dim=- 1
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.Flatten' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.Flatten(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_Unflatten)
class CalcNode_Unflatten(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_Unflatten
    op_title = "Unflatten"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_Unflatten"

    def initInnerClasses(self):
        global pas
        pas = """
dim=1
unflattened_size=(2,5,5)
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.Unflatten' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.Unflatten(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_Linear)
class CalcNode_LINEAR(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_Linear
    op_title = "Linear"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_linear"

    def initInnerClasses(self):
        global pas
        pas = """
in_features=3
out_features=4
bias=True
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.Linear' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.Linear(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_MaxPool1d)
class CalcNode_MaxPool1d(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_MaxPool1d
    op_title = "MaxPool1d"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_MaxPool1d"

    def initInnerClasses(self):
        global pas
        pas = """
kernel_size=10
stride=None
padding=0
dilation=1
return_indices=False
ceil_mode=False
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.MaxPool1d' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.MaxPool1d(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_MaxPool2d)
class CalcNode_MaxPool2d(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_MaxPool2d
    op_title = "MaxPool2d"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_MaxPool2d"

    def initInnerClasses(self):
        global pas
        pas = """
kernel_size=10
stride=None
padding=0
dilation=1
return_indices=False
ceil_mode=False
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.MaxPool2d' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.MaxPool2d(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_MaxPool3d)
class CalcNode_MaxPool3d(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_MaxPool3d
    op_title = "MaxPool3d"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_MaxPool3d"

    def initInnerClasses(self):
        global pas
        pas = """
kernel_size=10
stride=None
padding=0
dilation=1
return_indices=False
ceil_mode=False
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.MaxPool3d' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.MaxPool3d(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_RELU)
class CalcNode_RELU(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_RELU
    op_title = "ReLU"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_RELU"

    def initInnerClasses(self):
        global pas
        pas = """
inplace=False
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.ReLU' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.ReLU(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_GELU)
class CalcNode_GELU(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_GELU
    op_title = "GELU"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_GELU"

    def initInnerClasses(self):
        global pas
        pas = """
inplace=False        
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.GELU' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.GELU()(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_Reshape)
class CalcNode_Reshape(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_Reshape
    op_title = "Reshape"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_Reshape"

    def initInnerClasses(self):
        global pas
        pas = """
(1,-1)
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = torch.reshape(input1, eval(u_value))
        except:
            self.markDirty()
        return self.value

@register_node(OP_NODE_Custom)
class CalcNode_Custom(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_Custom
    op_title = "Custom"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_Custom"

    def initInnerClasses(self):
        global pas
        pas = """
PReLU
(1,2)
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            if '(' in u_value:
                self.value = torch.randn(eval('(' + u_value.split('(')[-1]))
            else:
                self.value = input1
        except:
            self.markDirty()
        return self.value

@register_node(OP_NODE_LayerNorm)
class CalcNode_GELU(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_LayerNorm
    op_title = "LayerNorm"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_LayerNorm"

    def initInnerClasses(self):
        global pas
        pas = """
normalized_shape=2
eps=1e-05
elementwise_affine=True
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.LayerNorm' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.LayerNorm(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_Dropout)
class CalcNode_DROPOUT(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_Dropout
    op_title = "Dropout"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_DROPOUT"

    def initInnerClasses(self):
        global pas
        pas = """
p=0.5
inplace=False
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.Dropout' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.Dropout(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value

@register_node(OP_NODE_Dropout1d)
class CalcNode_Dropout1d(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_Dropout1d
    op_title = "Dropout1d"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_Dropout1d"

    def initInnerClasses(self):
        global pas
        pas = """
p=0.5
inplace=False
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.Dropout1d' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.Dropout1d(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value

@register_node(OP_NODE_Dropout2d)
class CalcNode_Dropout2d(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_Dropout2d
    op_title = "Dropout2d"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_Dropout2d"

    def initInnerClasses(self):
        global pas
        pas = """
p=0.5
inplace=False
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.Dropout2d' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.Dropout2d(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value

@register_node(OP_NODE_Dropout3d)
class CalcNode_Dropout3d(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_Dropout3d
    op_title = "Dropout3d"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_Dropout3d"

    def initInnerClasses(self):
        global pas
        pas = """
p=0.5
inplace=False
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.Dropout3d' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.Dropout3d(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value

@register_node(OP_NODE_AvgPool1d)
class CalcNode_AvgPool1d(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_AvgPool1d
    op_title = "AvgPool1d"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_AvgPool1d"

    def initInnerClasses(self):
        global pas
        pas = """
kernel_size=3
stride=None
padding=0
ceil_mode=False
count_include_pad=True
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.AvgPool1d' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.AvgPool1d(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_AvgPool2d)
class CalcNode_AvgPool2d(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_AvgPool2d
    op_title = "AvgPool2d"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_AvgPool2d"

    def initInnerClasses(self):
        global pas
        pas = """
kernel_size=3
stride=None
padding=0
ceil_mode=False
count_include_pad=True
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.AvgPool2d' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.AvgPool2d(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_AvgPool3d)
class CalcNode_AvgPool3d(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_AvgPool3d
    op_title = "AvgPool3d"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_AvgPool3d"

    def initInnerClasses(self):
        global pas
        pas = """
kernel_size=3
stride=None
padding=0
ceil_mode=False
count_include_pad=True
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.AvgPool3d' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.AvgPool3d(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_AdaptiveAvgPool1d)
class CalcNode_AdaptiveAvgPool1d(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_AdaptiveAvgPool1d
    op_title = "AdaptiveAvgPool1d"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_AdaptiveAvgPool1d"

    def initInnerClasses(self):
        global pas
        pas = """
output_size=1
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.AdaptiveAvgPool1d' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.AdaptiveAvgPool1d(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_AdaptiveAvgPool2d)
class CalcNode_AdaptiveAvgPool2d(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_AdaptiveAvgPool2d
    op_title = "AdaptiveAvgPool2d"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_AdaptiveAvgPool2d"

    def initInnerClasses(self):
        global pas
        pas = """
output_size=1
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.AdaptiveAvgPool2d' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.AdaptiveAvgPool2d(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_AdaptiveAvgPool3d)
class CalcNode_AdaptiveAvgPool3d(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_AdaptiveAvgPool3d
    op_title = "AdaptiveAvgPool3d"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_AdaptiveAvgPool3d"

    def initInnerClasses(self):
        global pas
        pas = """
output_size=1
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.AdaptiveAvgPool3d' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.AdaptiveAvgPool3d(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_AdaptiveMaxPool1d)
class CalcNode_AdaptiveMaxPool1d(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_AdaptiveMaxPool1d
    op_title = "AdaptiveMaxPool1d"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_AdaptiveMaxPool1d"

    def initInnerClasses(self):
        global pas
        pas = """
output_size=1
return_indices=False
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.AdaptiveMaxPool1d' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.AdaptiveMaxPool1d(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_AdaptiveMaxPool2d)
class CalcNode_AdaptiveMaxPool2d(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_AdaptiveMaxPool2d
    op_title = "AdaptiveMaxPool2d"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_AdaptiveMaxPool2d"

    def initInnerClasses(self):
        global pas
        pas = """
output_size=1
return_indices=False
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.AdaptiveMaxPool2d' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.AdaptiveMaxPool2d(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_AdaptiveMaxPool3d)
class CalcNode_AdaptiveMaxPool3d(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_AdaptiveMaxPool3d
    op_title = "AdaptiveMaxPool3d"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_AdaptiveMaxPool3d"

    def initInnerClasses(self):
        global pas
        pas = """
output_size=1
return_indices=False
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.AdaptiveMaxPool3d' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.AdaptiveMaxPool3d(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


# torch.nn.AdaptiveMaxPool2d()

@register_node(OP_NODE_Softmax)
class CalcNode_Softmax(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_Softmax
    op_title = "Softmax"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_Softmax"

    def initInnerClasses(self):
        global pas
        pas = """
dim=None
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.Softmax' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.Softmax(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_SUM)
class CalcNode_SUM(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_SUM
    op_title = "Sum"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_Sum"

    def initInnerClasses(self):
        global pas
        pas = """
dim=None
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.sum' + str(u_value))(input1)
        except:
            try:
                self.value = torch.sum(input1, **convert_string_to_dict(str(u_value)))
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_Repeat)
class CalcNode_Repeat(CalcNode2):
    # icon = "icons/divide.png"
    op_code = OP_NODE_Repeat
    op_title = "Repeat"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_Repeat"

    def evalOperation(self, input1, input2):
        # print(input2)
        return repeat(input1, **input2)


# @register_node(OP_NODE_Repeat)
# class CalcNode_Repeat(CalcNode):
#     # icon = "icons/divide.png"
#     op_code = OP_NODE_Repeat
#     op_title = "Repeat"
#     # content_label = "Conv2d"
#     content_label_objname = "calc_node_Repeat"
#
#     def initInnerClasses(self):
#         global pas
#         pas = """
# 'h w -> (repeat h) w', repeat=2
# """
#         self.content = CalcInputContent(self)
#         self.grNode = CalcGraphicsNode(self)
#         self.content.edit.textChanged.connect(self.onInputChanged)
#
#     def evalOperation(self, input1):
#         self.ss = input1
#         u_value = self.content.edit.toPlainText()
#         self.value = None
#         try:
#             self.value = eval(f'repeat({input1},{u_value})')
#         except:
#             try:
#                 self.value = Rearrange(**convert_string_to_dict(str(u_value)))(input1)
#             except:
#                 self.markDirty()
#         return self.value


@register_node(OP_NODE_Rearrange)
class CalcNode_Rearrange(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_Rearrange
    op_title = "Rearrange"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_Rearrange"

    def initInnerClasses(self):
        global pas
        pas = """
pattern='b h w c -> b (c h w)'
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('Rearrange' + str(u_value))(input1)
        except:
            try:
                self.value = Rearrange(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


# @register_node(OP_NODE_Rearrange)
# class CalcNode_Rearrange(CalcNode2):
#     # icon = "icons/divide.png"
#     op_code = OP_NODE_Rearrange
#     op_title = "Rearrange"
#     # content_label = "Conv2d"
#     content_label_objname = "calc_node_Rearrange"
#
#     def evalOperation(self, input1, input2):
#         # print(input2)
#         # Rearrange(pattern='')
#         try:
#             return eval('Rearrange'+str(input2))(input1)
#         except:
#             return Rearrange(**input2)(input1)

@register_node(OP_NODE_Reduce)
class CalcNode_Reduce(CalcNode):
    # icon = "icons/divide.png"
    op_code = OP_NODE_Reduce
    op_title = "Reduce"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_Reduce"

    def initInnerClasses(self):
        global pas
        pas = """
pattern='b h w c -> b (c h w)'
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('Reduce' + str(u_value))(input1)
        except:
            try:
                self.value = Reduce(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


# @register_node(OP_NODE_Reduce)
# class CalcNode_Rearrange(CalcNode2):
#     # icon = "icons/divide.png"
#     op_code = OP_NODE_Reduce
#     op_title = "Reduce"
#     # content_label = "Conv2d"
#     content_label_objname = "calc_node_Reduce"
#
#     def evalOperation(self, input1, input2):
#         # print(input2)
#         try:
#             return eval('Reduce'+str(input2))(input1)
#         except:
#             return Reduce(**input2)(input1)

@register_node(OP_NODE_Matmul)
class CalcNode_Matmul(CalcNode2):
    # icon = "icons/divide.png"
    op_code = OP_NODE_Matmul
    op_title = "Matmul"
    # content_label = "Conv2d"
    content_label_objname = "calc_node_Matmul"

    def evalOperation(self, input1, input2):
        # print(input2)

        return torch.matmul(input1, input2)


@register_node(OP_NODE_Sigmoid)
class CalcNode_Softmax(CalcNode):
    op_code = OP_NODE_Sigmoid
    op_title = "Sigmoid"
    content_label_objname = "calc_node_Sigmoid"

    def initInnerClasses(self):
        global pas
        pas = """
inplace=False
"""
        self.content = CalcInputContent(self)
        self.grNode = CalcGraphicsNode(self)
        self.content.edit.textChanged.connect(self.onInputChanged)

    def evalOperation(self, input1):
        self.ss = input1
        u_value = self.content.edit.toPlainText()
        self.value = None
        try:
            self.value = eval('torch.nn.Sigmoid' + str(u_value))(input1)
        except:
            try:
                self.value = torch.nn.Sigmoid(**convert_string_to_dict(str(u_value)))(input1)
            except:
                self.markDirty()
        return self.value


@register_node(OP_NODE_Stack0)
class CalcNode_Rearrange(CalcNode2):
    op_code = OP_NODE_Stack0
    op_title = "Stack0"
    content_label_objname = "calc_node_Stack0"

    def evalOperation(self, input1, input2):
        return torch.stack([input1, input2], 0)


@register_node(OP_NODE_Stack1)
class CalcNode_Rearrange(CalcNode2):
    op_code = OP_NODE_Stack1
    op_title = "Stack1"
    content_label_objname = "calc_node_Stack1"

    def evalOperation(self, input1, input2):
        return torch.stack([input1, input2], 1)


@register_node(OP_NODE_Cat0)
class CalcNode_Rearrange(CalcNode2):
    op_code = OP_NODE_Cat0
    op_title = "Cat0"
    content_label_objname = "calc_node_Cat0"

    def evalOperation(self, input1, input2):
        return torch.cat([input1, input2], 0)


@register_node(OP_NODE_Cat1)
class CalcNode_Rearrange(CalcNode2):
    op_code = OP_NODE_Cat1
    op_title = "Cat1"
    content_label_objname = "calc_node_Cat1"

    def evalOperation(self, input1, input2):
        return torch.cat([input1, input2], 1)
